This app was made by Krista Dotzenrod on 12/1/2019 for the Flipgrid coding challenge 

It contains a simple form for a user to register for an imaginary service using their 
name, email address, and a password. The users' name and email address are then sent
to the Confirmation activity intent and displayed once the SIGN UP button is selected